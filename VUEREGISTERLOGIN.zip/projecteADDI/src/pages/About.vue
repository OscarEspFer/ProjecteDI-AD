<template>
  <q-page class="flex flex-center">
    <div>
      <h1>Projecte ADDI</h1>
      <br>
      <p>Projecte ADDI fet per Oscar España Ferrer</p>
    </div>
  </q-page>
</template>

<script>
export default {
  name: 'PageIndex'
}
</script>
